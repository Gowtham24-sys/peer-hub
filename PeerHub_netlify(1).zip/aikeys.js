/* PeerHub — "use my own AI key" (bring your own key).
   Keys are saved ONLY on this phone/browser (localStorage). They are never saved on our servers: the app sends them
   with a single request (header x-user-keys) and the server uses them just for that request.
   Needs: core.js (PH). Pages call AIK.has(), AIK.headers(), AIK.open(), AIK.paywall(kind), AIK.banner(el). */
(function () {
  const LS = 'ph_ai_keys';
  // Free providers only. max = how many keys can be saved for it.
  const PROVIDERS = [
    { id: 'gemini', name: 'Google Gemini', badge: 'Best · reads photos', max: 3, url: 'https://aistudio.google.com/apikey',
      tip: 'Open the page → sign in with your Gmail → tap “Create API key” → copy it. Takes 1 minute. You can add up to 3 keys (different Google projects).' },
    { id: 'groq', name: 'Groq', badge: 'Very fast', max: 1, url: 'https://console.groq.com/keys',
      tip: 'Open → sign up with Gmail → “Create API Key” → copy it.' },
    { id: 'openrouter', name: 'OpenRouter', badge: 'Many free models', max: 1, url: 'https://openrouter.ai/settings/keys',
      tip: 'Open → sign in with Google → “Create Key” → copy it. Free models have a daily limit.' },
    { id: 'mistral', name: 'Mistral', badge: 'Free plan · reads photos', max: 1, url: 'https://console.mistral.ai/api-keys',
      tip: 'Open → create an account (phone verification) → choose the free “Experiment” plan → “Create new key”.' },
    { id: 'cerebras', name: 'Cerebras', badge: 'Free · text only', max: 1, url: 'https://cloud.cerebras.ai',
      tip: 'Open → sign in → “API Keys” → “Generate”. Good as a backup for making tests.' },
    { id: 'zai', name: 'Z.ai (GLM)', badge: 'Free models', max: 1, url: 'https://z.ai/manage-apikey/apikey-list',
      tip: 'Open → sign in → “Create a new API key” → copy it.' },
    { id: 'cohere', name: 'Cohere', badge: 'Free trial key', max: 1, url: 'https://dashboard.cohere.com/api-keys',
      tip: 'Open → sign in → copy the “Trial key”. Trial keys are for personal use.' },
    { id: 'cloudflare', name: 'Cloudflare Workers AI', badge: 'Free daily limit', max: 1, two: true, url: 'https://dash.cloudflare.com/profile/api-tokens',
      tip: 'Needs 2 things: your Account ID (Workers & Pages page) and an API token with “Workers AI” permission.' },
  ];

  let mem = {};
  const read = () => { try { const j = JSON.parse(localStorage.getItem(LS) || 'null'); if (j && typeof j === 'object') return j; } catch (_) {} return mem; };
  const write = (o) => { mem = o; try { localStorage.setItem(LS, JSON.stringify(o)); } catch (_) {} };
  const list = (id) => { const v = read()[id]; if (id === 'cloudflare') return v && v.account && v.token ? [v] : []; return Array.isArray(v) ? v.filter(Boolean) : v ? [v] : []; };
  const mask = (k) => '••••' + String(typeof k === 'object' ? k.token : k).slice(-4);
  const css = document.createElement('style');
  css.textContent = `.aik-row{border:1px solid var(--line,#333);background:var(--card,#16162a);border-radius:16px;padding:12px;margin-bottom:10px}
  .aik-row b{font-size:15px}.aik-b{font-size:10.5px;font-weight:800;padding:2px 8px;border-radius:99px;background:color-mix(in srgb,var(--good,#14c99a) 22%,transparent);color:var(--good,#14c99a);margin-left:6px;white-space:nowrap}
  .aik-tip{font-size:12.5px;color:var(--muted,#999);margin:6px 0 8px;line-height:1.45}
  .aik-go{display:inline-block;font-weight:800;font-size:13px;color:var(--accent,#7c6cff);text-decoration:none;margin-bottom:8px;cursor:pointer;background:none;border:0;padding:0}
  .aik-in{display:flex;gap:8px;margin-top:6px}.aik-in input{flex:1;min-width:0}
  .aik-saved{display:flex;align-items:center;gap:8px;margin-top:6px;font-size:14px}.aik-saved .grow{flex:1}
  .aik-banner{border-radius:22px;padding:18px;margin:20px 0 6px;background:linear-gradient(135deg,color-mix(in srgb,var(--accent,#7c6cff) 38%,transparent),color-mix(in srgb,var(--accent2,#ff5fa2) 30%,transparent));border:1px solid color-mix(in srgb,var(--accent,#7c6cff) 45%,transparent)}
  .aik-banner h3{margin:0 0 4px;font-size:18px}.aik-banner p{margin:0 0 12px;font-size:13.5px;opacity:.9;line-height:1.45}`;
  document.head.appendChild(css);

  const AIK = {
    PROVIDERS,
    has() { return PROVIDERS.some((p) => list(p.id).length); },
    count() { return PROVIDERS.reduce((n, p) => n + list(p.id).length, 0); },
    // header value for the server: base64 of {provider: key(s)}; used for ONE request only
    headers() {
      const o = {}; PROVIDERS.forEach((p) => { const l = list(p.id); if (!l.length) return; o[p.id] = p.id === 'cloudflare' ? l[0] : (p.max > 1 ? l : l[0]); });
      return Object.keys(o).length ? { 'x-user-keys': btoa(JSON.stringify(o)) } : {};
    },
    open(onChange) {
      const esc = PH.esc;
      const s = PH.sheet('<div id="aikBox"></div>');
      const box = s.el.querySelector('#aikBox');
      const draw = () => {
        box.innerHTML = `<h2>🔑 Your AI keys</h2>
          <p class="muted small" style="margin:4px 0 12px;line-height:1.5">Paste a free key and use AI features with no limit from us. <b>Your key stays on this phone only</b> — we never save it on our servers; it is sent securely just for the moment you press a button. If one key fails or is full, the next one is used automatically. Add as many as you like.</p>
          ${PROVIDERS.map((p) => {
            const l = list(p.id);
            const saved = l.map((k, i) => `<div class="aik-saved"><span>✓</span><span class="grow">Key saved <span class="muted">${esc(mask(k))}</span></span><button class="link" data-rm="${p.id}" data-i="${i}" type="button">Remove</button></div>`).join('');
            const input = l.length >= p.max ? '' : p.two
              ? `<div class="aik-in"><input class="input" data-f="${p.id}-a" placeholder="Account ID" autocomplete="off" /></div><div class="aik-in"><input class="input" data-f="${p.id}-t" type="password" placeholder="API token" autocomplete="off" /><button class="btn small" data-add="${p.id}" type="button">Save</button></div>`
              : `<div class="aik-in"><input class="input" data-f="${p.id}" type="password" placeholder="${l.length ? 'Add another key' : 'Paste your key here'}" autocomplete="off" /><button class="btn small" data-add="${p.id}" type="button">Save</button></div>`;
            return `<div class="aik-row"><div><b>${esc(p.name)}</b><span class="aik-b">${esc(p.badge)}</span></div><div class="aik-tip">${esc(p.tip)}</div>
              <button class="aik-go" data-go="${esc(p.url)}" type="button">Get a free key ↗</button>${saved}${input}</div>`; }).join('')}`;
      };
      draw();
      box.onclick = (e) => {
        const go = e.target.closest('[data-go]'); if (go) return void window.open(go.dataset.go, '_blank', 'noopener');
        const rm = e.target.closest('[data-rm]'); if (rm) { const o = read(), id = rm.dataset.rm; if (id === 'cloudflare') delete o[id]; else { const a = list(id); a.splice(+rm.dataset.i, 1); if (a.length) o[id] = a; else delete o[id]; } write(o); draw(); onChange && onChange(); return; }
        const add = e.target.closest('[data-add]'); if (!add) return; const id = add.dataset.add, o = read();
        if (id === 'cloudflare') { const a = box.querySelector('[data-f="cloudflare-a"]').value.trim(), t = box.querySelector('[data-f="cloudflare-t"]').value.trim();
          if (a.length < 8 || t.length < 8) return PH.toast('Enter both the Account ID and the token', 'error'); o[id] = { account: a, token: t }; }
        else { const v = box.querySelector(`[data-f="${id}"]`).value.trim().replace(/\s+/g, '');
          if (v.length < 8) return PH.toast('That does not look like a key', 'error');
          const a = list(id); if (a.includes(v)) return PH.toast('Already saved', 'info'); a.push(v); o[id] = a; }
        write(o); PH.toast('Key saved on this phone ✓', 'success'); draw(); onChange && onChange();   // the box is redrawn: the key is hidden now
      };
      return s;
    },
    // shown when the free trials are over
    paywall(kind) {
      const what = kind === 'making' ? 'making papers' : 'paper correction';
      const s = PH.sheet(`<h2>Free trials are over</h2><p class="muted small" style="margin:6px 0 14px;line-height:1.5">You used your free trials for ${what}. Add your own free AI key to continue:</p>
        <div class="stack"><button class="btn" id="pk1">🔑 Use my own free AI key</button><p class="muted small" style="margin:-4px 0 4px">Free. Paste a key once — it stays on your phone. 1–2 minutes.</p>
        </div>`);
      s.el.querySelector('#pk1').onclick = () => { s.close(); AIK.open(() => {}); };
    },
    // big card for the bottom of a page
    banner(el) {
      if (!el) return;
      const draw = () => { const n = AIK.count();
        el.innerHTML = `<div class="aik-banner"><h3>🔑 Use your own free AI key</h3>
          <p>Paste your free API key once — it stays safe on your phone and you can use AI features freely.${n ? `<br/><b>${n} key${n > 1 ? 's' : ''} saved ✓</b>` : ''}</p>
          <div class="row" style="gap:8px"><button class="btn grow" id="aikOpen" type="button">${n ? 'Manage my keys' : 'Add my keys'}</button></div></div>`;
        el.querySelector('#aikOpen').onclick = () => AIK.open(draw); };
      draw();
    },
  };
  window.AIK = AIK;
})();
