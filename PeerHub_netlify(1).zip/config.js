// PASTE YOUR SUPABASE VALUES HERE (only place you ever need to do this)
// Supabase Dashboard -> Project Settings -> API
window.PEERHUB = {
  SUPABASE_URL: 'https://zxjvlhrnjdssjesqqfdw.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_e07V9sJKaLM77j6aG8boxA_LFhAM6dE' // publishable (public) key - safe in the app
};
