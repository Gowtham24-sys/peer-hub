/* PeerHub shared helpers. Every page loads: config.js -> supabase CDN -> core.js */
(function () {
  const cfg = window.PEERHUB || {};
  const configured = /^https?:\/\//.test(cfg.SUPABASE_URL || '') && cfg.SUPABASE_ANON_KEY && !String(cfg.SUPABASE_ANON_KEY).startsWith('YOUR');
  const db = configured && window.supabase ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;

  const PH = { db, configured };

  // ---------- small utils ----------
  PH.esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  PH.initials = (name) => (String(name || '?').trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join('') || '?').toUpperCase();
  PH.todayISO = () => new Date(Date.now() + 5.5 * 3600 * 1000 - new Date().getTimezoneOffset() * -60000 * 0).toISOString().slice(0, 10);
  // today's date in India time (YYYY-MM-DD)
  PH.todayISO = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata' }).format(new Date());
  PH.fmtDate = (iso, opts) => new Date(iso + 'T00:00:00').toLocaleDateString('en-IN', opts || { weekday: 'short', day: 'numeric', month: 'short' });

  // ---------- toast ----------
  PH.toast = (msg, type = 'info') => {
    let box = document.getElementById('toasts');
    if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
    const t = document.createElement('div');
    t.className = 'toast ' + type; t.textContent = msg; box.appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, 3200);
  };

  // ---------- backend calls ----------
  PH.rpc = async (name, args) => {
    if (!db) throw new Error('Supabase is not configured. Open config.js and paste your URL and anon key.');
    const { data, error } = await db.rpc(name, args || {});
    if (error) throw new Error(error.message || 'Something went wrong');
    return data;
  };

  // ---------- session + context ----------
  PH.clearCtx = () => sessionStorage.removeItem('ph_ctx');
  PH.context = async (force) => {
    if (!force) { try { const c = JSON.parse(sessionStorage.getItem('ph_ctx') || 'null'); if (c) return c; } catch (_) {} }
    const ctx = await PH.rpc('my_context');
    try { sessionStorage.setItem('ph_ctx', JSON.stringify(ctx)); } catch (_) {}
    return ctx;
  };
  // Call at the top of every inner page. Sends people to register.html if not logged in / no group yet.
  PH.requireAuth = async () => {
    if (!db) { PH.toast('Add your Supabase keys in config.js', 'error'); return null; }
    const { data: { session } } = await db.auth.getSession();
    if (!session) { location.replace('register.html'); return null; }
    let ctx;
    try { ctx = await PH.context(); } catch (e) { PH.toast(e.message, 'error'); return null; }
    if (!ctx.group) { location.replace('register.html'); return null; }
    return { session, ctx, user: session.user, group: ctx.group, role: ctx.role,
             isStaff: ['admin', 'cr1', 'cr2'].includes(ctx.role), isAdmin: ctx.role === 'admin' };
  };
  PH.logout = async () => { await db.auth.signOut(); PH.clearCtx(); location.replace('register.html'); };

  // ---------- private images (signed URLs) ----------
  const urlCache = new Map();
  PH.signedUrl = async (bucket, path) => {
    if (!path) return null;
    const key = bucket + '/' + path;
    const hit = urlCache.get(key);
    if (hit && hit.exp > Date.now()) return hit.url;
    const { data } = await db.storage.from(bucket).createSignedUrl(path, 3600);
    if (data && data.signedUrl) { urlCache.set(key, { url: data.signedUrl, exp: Date.now() + 3300 * 1000 }); return data.signedUrl; }
    return null;
  };
  // <span class="avatar" data-avatar="path" data-name="Gowtham"></span>  -> call PH.fillAvatars()
  PH.avatarHtml = (name, path, size) =>
    `<span class="avatar" ${size ? `style="--s:${size}px"` : ''} data-avatar="${PH.esc(path || '')}">${PH.esc(PH.initials(name))}</span>`;
  PH.fillAvatars = async (root) => {
    const els = (root || document).querySelectorAll('.avatar[data-avatar]:not([data-done])');
    for (const el of els) {
      el.dataset.done = '1';
      const p = el.dataset.avatar; if (!p) continue;
      PH.signedUrl('avatars', p).then((u) => { if (u) { el.style.backgroundImage = `url("${u}")`; el.textContent = ''; el.classList.add('has-img'); } });
    }
  };

  // ---------- bottom navigation ----------
  const NAV = [
    { id: 'attendance', label: 'Attendance', icon: '📅', href: 'attendance.html' },
    { id: 'study', label: 'Study', icon: '📚', href: 'study.html' },
    { id: 'home', label: 'Home', icon: '🏠', href: 'home.html' },
    { id: 'tests', label: 'Tests', icon: '🧠', href: 'tests.html' },
    { id: 'games', label: 'Games', icon: '🎮', href: 'games.html' },
  ];
  PH.nav = (active) => {
    const nav = document.createElement('nav');
    nav.className = 'bottom-nav';
    nav.innerHTML = NAV.map((n) => `<a href="${n.href}" class="${n.id === active ? 'on' : ''}"><span class="ic">${n.icon}</span><span>${n.label}</span></a>`).join('');
    document.body.appendChild(nav);
  };

  PH.setBusy = (btn, busy, text) => {
    if (!btn) return;
    if (busy) { btn.dataset.t = btn.textContent; btn.disabled = true; btn.textContent = text || 'Please wait…'; }
    else { btn.disabled = false; if (btn.dataset.t) btn.textContent = btn.dataset.t; }
  };

  // resize a photo before upload (keeps storage small and fast)
  PH.compress = (file, max = 1280, q = 0.82) => new Promise((res, rej) => {
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      const r = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width * r); c.height = Math.round(img.height * r);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      c.toBlob((b) => { URL.revokeObjectURL(url); b ? res(b) : rej(new Error('Could not read that photo')); }, 'image/jpeg', q);
    };
    img.onerror = () => rej(new Error('Could not read that photo'));
    img.src = url;
  });
  // Timetable photo -> small grayscale JPEG (target ~200 KB) so the AI reads it fast
  PH.compressForAI = (file, targetKB = 200) => new Promise((res, rej) => {
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      let max = 1500, q = 0.72, tries = 0;
      const run = () => {
        const r = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas'); c.width = Math.round(img.width * r); c.height = Math.round(img.height * r);
        const g = c.getContext('2d'); g.filter = 'grayscale(1) contrast(1.25)'; g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
        c.toBlob((b) => {
          if (!b) { URL.revokeObjectURL(url); return rej(new Error('Could not read that photo')); }
          if (b.size > targetKB * 1024 && tries < 5) { tries++; max = Math.round(max * 0.85); q = Math.max(0.5, q - 0.05); return run(); }
          URL.revokeObjectURL(url); res(b);
        }, 'image/jpeg', q);
      };
      run();
    };
    img.onerror = () => rej(new Error('Could not read that photo'));
    img.src = url;
  });
  PH.upload = async (bucket, path, blob, contentType) => {
    const { error } = await db.storage.from(bucket).upload(path, blob, { upsert: false, contentType: contentType || blob.type || 'image/jpeg' });
    if (error) throw new Error(error.message);
    return path;
  };

  // bottom sheet:  const s = PH.sheet('<h2>Hi</h2>');  s.el = content node,  s.close()
  PH.sheet = (html) => {
    const root = document.createElement('div'); root.className = 'modal';
    root.innerHTML = `<div class="sheet"><div class="handle"></div>${html}</div>`;
    document.body.appendChild(root);
    const close = () => root.remove();
    root.addEventListener('click', (e) => { if (e.target === root) close(); });
    return { el: root.querySelector('.sheet'), root, close };
  };

  // ---------- status look (shared by Home and Games) ----------
  PH.STATUS_BG = {
    sunset: 'linear-gradient(135deg,#ff7a59,#ff5fa2)', ocean: 'linear-gradient(135deg,#2e6fd8,#14c99a)', night: 'linear-gradient(135deg,#1b1b2f,#7c6cff)',
    forest: 'linear-gradient(135deg,#0f9b6b,#a3e635)', royal: 'linear-gradient(135deg,#7c6cff,#c16bff)', rose: 'linear-gradient(135deg,#ff5fa2,#ffb547)',
    gold: 'linear-gradient(135deg,#f4c430,#ff7a59)', slate: 'linear-gradient(135deg,#3a3a5c,#1a1a2e)' };
  PH.STATUS_FONT = { sans: 'inherit', serif: 'Georgia, "Times New Roman", serif', mono: 'ui-monospace, Menlo, monospace', script: '"Brush Script MT", "Segoe Script", cursive' };
  PH.STATUS_FILTER = { none: 'none', bw: 'grayscale(1)', warm: 'sepia(.5) saturate(1.4)', cool: 'hue-rotate(20deg) saturate(1.2) brightness(1.05)', fade: 'contrast(.85) brightness(1.1) saturate(.8)' };
  // quick text status (used for game achievements)
  PH.postStatusText = async (groupId, text, bg = 'gold', hours = 24) => {
    const { error } = await db.from('status_posts').insert({ group_id: groupId, kind: 'text', text_content: text, bg, font: 'sans', hours });
    if (error) throw new Error(error.message);
  };

  // ---------- subject symbols (matched by the subject's NAME, not its position) ----------
  const SUBJ_ICONS = [
    [/chem/i, '🧪'], [/physic/i, '⚛️'], [/bio|botany|zoology|life science/i, '🧬'], [/stat|probab/i, '📊'],
    [/math|calcul|algebra|geometry|trigon|numeric|discrete|aptitude|quant|reasoning/i, '📐'],
    [/data ?struct|algorithm|\bdsa\b|\bdaa\b/i, '🧩'], [/database|dbms|\bsql\b/i, '🗄️'], [/network|\bcn\b|internet/i, '🌐'],
    [/operating|\bos\b/i, '🖥️'], [/\bai\b|machine learning|artificial|deep learning|\bml\b|data ?science/i, '🤖'],
    [/web|html|css|javascript/i, '🕸️'], [/cyber|security|crypto/i, '🔐'],
    [/comput|program|coding|\bc\b|c\+\+|java|python|software|\bit\b|informatics|digital/i, '💻'],
    [/electr|circuit|\beee\b|\bece\b|signal|power|microprocessor|embedded|vlsi/i, '⚡'], [/electronic/i, '📡'],
    [/mechan|thermo|machine|fluid|manufactur|\bcad\b|robot/i, '⚙️'], [/civil|structur|survey|concrete|construction/i, '🏗️'],
    [/environment|\bevs\b|ecology|sustain/i, '🌱'], [/histor/i, '🏛️'], [/geograph/i, '🌍'], [/civic|polity|political|constitution/i, '⚖️'],
    [/econom/i, '💹'], [/account|financ|commerce|business|management|marketing|entrepreneur/i, '💼'], [/\blaw\b|legal/i, '⚖️'],
    [/draw|graphics|design|sketch/i, '✏️'], [/yoga|meditat/i, '🧘'], [/physical|sport|\bpe\b|games|fitness/i, '🏃'],
    [/music/i, '🎵'], [/\bart\b|painting|craft/i, '🎨'], [/commun|soft skill|speaking|presentation/i, '🎤'],
    [/ethic|value|moral|human/i, '🕊️'], [/telugu|hindi|sanskrit|urdu|tamil|kannada|malayalam|marathi|bengali|language/i, '🗣️'],
    [/english|grammar|literature|writing|reading/i, '📖'], [/anatomy|physiology|medic|health|nursing/i, '🫀'], [/pharm|drug/i, '💊'],
    [/agricultur|farming|crop/i, '🌾'], [/social|sociology|psycholog/i, '👥'], [/science|general|gk|knowledge/i, '🔬'],
    [/lab|practical|workshop/i, '🔬'], [/project|seminar|internship|mini/i, '🛠️'],
  ];
  PH.subjectIcon = (name) => { const n = String(name || ''); for (const [re, ic] of SUBJ_ICONS) if (re.test(n)) return ic; return '📘'; };

  window.PH = PH;
})();
