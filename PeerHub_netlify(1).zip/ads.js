/* PeerHub ads — every ad spot is controlled from the backend (table ad_slots).
   <div class="ad-slot" data-slot="home_bottom"></div>   -> fills at the end of a page
   PHAds.bar('game_play', overlayElement)                 -> sticky bar at the bottom edge while the overlay is open
   A slot that is disabled / deleted in the backend simply stays invisible. */
(function () {
  const css = document.createElement('style');
  css.textContent = `.ad-slot{display:none}.ad-slot.on{display:block;margin:18px 0 6px;text-align:center;overflow:hidden;border-radius:14px}
  .ad-slot .adl{font-size:10px;letter-spacing:.08em;color:var(--muted,#888);margin-bottom:3px;text-transform:uppercase}
  .ad-slot .adprev{border:1.5px dashed var(--line,#444);border-radius:14px;display:grid;place-items:center;color:var(--muted,#888);font-size:12px}
  .ad-bar{position:fixed;left:0;right:0;bottom:0;z-index:120;background:var(--bg,#0B0B16);border-top:1px solid var(--line,#333);padding:4px 8px calc(4px + env(safe-area-inset-bottom));text-align:center;overflow:hidden}
  .ad-bar .adl{display:none}`;
  document.head.appendChild(css);

  let cfg = null, loading = null, adsenseLoaded = null;
  const native = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());

  function load() {
    if (cfg) return Promise.resolve(cfg);
    if (!loading) loading = PH.rpc('list_ad_slots').then((r) => (cfg = r || { enabled: false, slots: {} })).catch(() => (cfg = { enabled: false, slots: {} }));
    return loading;
  }
  function loadAdsense(client) {
    if (adsenseLoaded) return adsenseLoaded;
    adsenseLoaded = new Promise((res) => { const s = document.createElement('script'); s.async = true; s.crossOrigin = 'anonymous'; s.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + encodeURIComponent(client); s.onload = res; s.onerror = res; document.head.appendChild(s); });
    return adsenseLoaded;
  }
  // fills `el` with the slot's ad; returns true if something is shown
  async function fill(el, key) {
    const c = await load(); const s = c.enabled && c.slots && c.slots[key];
    if (!s) return false;
    if ((s.platform === 'web' && native()) || (s.platform === 'app' && !native())) return false;
    const box = document.createElement('div'); box.style.minHeight = (s.min_height || 60) + 'px';
    if (s.provider === 'adsense' && s.client_id && s.ad_unit) {
      box.innerHTML = '<ins class="adsbygoogle" style="display:block" data-ad-client="' + s.client_id.replace(/"/g, '') + '" data-ad-slot="' + String(s.ad_unit).replace(/"/g, '') + '" data-ad-format="' + (s.format || 'auto').replace(/"/g, '') + '" data-full-width-responsive="true"></ins>';
      await loadAdsense(s.client_id);
      try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (_) {}
    } else if (s.provider === 'html' && s.html) {
      box.appendChild(document.createRange().createContextualFragment(s.html));   // your own code; scripts run
    } else if (s.provider === 'admob' && native() && s.ad_unit) {
      // hook for the AdMob plugin when the Android app is built
      window.dispatchEvent(new CustomEvent('peerhub-admob', { detail: { slot: key, unit: s.ad_unit, el: box } }));
    } else if (c.preview) {
      box.innerHTML = '<div class="adprev" style="min-height:' + (s.min_height || 60) + 'px">Ad space · ' + key + '</div>';
    } else return false;
    el.innerHTML = '<div class="adl">Ad</div>'; el.appendChild(box); el.classList.add('on');
    return true;
  }
  window.PHAds = {
    mount(root) { (root || document).querySelectorAll('.ad-slot[data-slot]').forEach((el) => { fill(el, el.dataset.slot).catch(() => {}); }); },
    // sticky bottom-edge bar that lives as long as `owner` stays in the page
    async bar(key, owner) {
      const el = document.createElement('div'); el.className = 'ad-bar';
      const ok = await fill(el, key).catch(() => false);
      if (!ok || !owner || !owner.isConnected) return;
      el.classList.add('on'); document.body.appendChild(el);
      const pad = owner.style.paddingBottom; owner.style.paddingBottom = 'calc(' + (el.offsetHeight + 12) + 'px + env(safe-area-inset-bottom))';
      const t = setInterval(() => { if (!owner.isConnected) { clearInterval(t); el.remove(); } }, 800);
    },
  };
})();
