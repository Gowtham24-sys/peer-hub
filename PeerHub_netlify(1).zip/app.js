// ====== 1) CONFIG: paste your Supabase values (Project Settings -> API) ======
const SUPABASE_URL = (window.PEERHUB || {}).SUPABASE_URL || '';   // set in config.js
const SUPABASE_ANON_KEY = (window.PEERHUB || {}).SUPABASE_ANON_KEY || '';

const supa = (SUPABASE_URL.startsWith('http') && window.supabase)
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

// ====== 2) Fallback content (used if Supabase is not configured/offline) ======
const FALLBACK = [
  { id: 1, title: 'Attendance', subtitle: 'Never get caught short on attendance again', icon: '📅', accent: '#6C5CE7', features: [
    ['Daily Tracker & Calculator', 'Easily log your daily classes and let the app automatically calculate your total percentage.'],
    ['Weekly & Monthly Breakdown', 'Get clear visual reports of your attendance trends over weeks and months.'],
    ['Exam Eligibility Alert', 'Know instantly if your current attendance meets the required threshold for upcoming exams.'],
    ['Subject-Wise Analysis', 'Spot exactly which subjects you attend the most and which ones you are lagging behind in.'],
    ["The 'Bunk Predictor'", 'See exactly how missing a future class will drop your final percentage before you decide.'] ] },
  { id: 2, title: 'Study Materials', subtitle: 'Your whole class, one shared library', icon: '📚', accent: '#00B894', features: [
    ['Subject-Wise Organization', 'Separate sections for every individual subject.'],
    ['Class Notes Sharing', 'Upload and access all subject notes in one place.'],
    ['Important Questions Bank', 'Share and find crucial questions for exam prep.'],
    ['Daily Homework Tracker', 'Post and view daily assignments so no one misses out.'],
    ['Collaborative Study Hub', 'A community-driven space where the whole class helps each other.'] ] },
  { id: 3, title: 'Test & AI Evaluation', subtitle: 'Practice smarter with AI', icon: '🧠', accent: '#E17055', features: [
    ['Subject-Wise AI Quizzes', 'Generate 10-50 MCQs automatically from your uploaded syllabus or notes.'],
    ['Weekly Syllabus Tests', "Take regular class-wide tests based on the current week's topics."],
    ['Exam-Time PYQ Practice', 'Upload previous papers with your handwritten answers. AI assigns marks and points out mistakes.'],
    ['Note-Based Explanations', 'Get explanations sourced from your class notes, shown only after quiz completion.'],
    ['Class Leaderboard', 'See the top 3 performers after every test to build healthy competition.'] ] },
  { id: 4, title: 'Game / Relax Zone', subtitle: 'Unwind with classic classroom games', icon: '🎮', accent: '#0984E3', features: [
    ['Stress Relief Zone', 'Relax and play multiplayer games with classmates during free times.'],
    ['Non-Distracting Gameplay', 'Simple, nostalgic time-pass games designed for fun, not addiction.'],
    ['Smart Time-Locks', 'Open only in the afternoons (after college) and fully open on Sundays.'],
    ['Classic Games Collection', 'Hand Cricket, SOS, Bingo, Tic-Tac-Toe, Hangman and FLAMES.'],
    ['Gaming Leaderboard', 'Track your game rankings and compete with friends for the top spot.'] ] },
  { id: 5, title: 'Home Dashboard', subtitle: 'Everything happening in your class', icon: '🏠', accent: '#E84393', features: [
    ['Daily Thoughts & GK', 'Interactive daily quotes and multiple-choice GK questions shared by students.'],
    ['Birthday Spotlights', "Full-screen photo celebrations for classmates' birthdays."],
    ['Smart Calendar & Timetable', 'Track schedules and get automated exam countdown reminders.'],
    ['Digital Notice Board', 'Official class announcements board.'],
    ['CR Elections & Roles', 'Vote for your Class Representative, who manages notices and gets reminders to post notes.'] ] },
];

// ====== 3) State & elements ======
let slides = [];
let index = 0;
const $ = (id) => document.getElementById(id);
const track = $('track'), dots = $('dots'), nextBtn = $('nextBtn'), backBtn = $('backBtn'), skipBtn = $('skipBtn'), card = $('card');

// ====== 4) Load content from Supabase (falls back to local) ======
async function loadSlides() {
  if (supa) {
    try {
      const { data, error } = await supa
        .from('onboarding_slides')
        .select('id, position, title, subtitle, icon, accent, onboarding_features(position, title, description)')
        .order('position');
      if (!error && data && data.length) {
        return data.map((s) => ({
          ...s,
          features: s.onboarding_features
            .sort((a, b) => a.position - b.position)
            .map((f) => [f.title, f.description]),
        }));
      }
    } catch (e) { console.warn('Supabase load failed, using fallback', e); }
  }
  return FALLBACK;
}

// ====== 5) Render ======
function render() {
  track.innerHTML = slides.map((s, i) => `
    <article class="slide" data-i="${i}" style="--accent:${s.accent}">
      <div class="icon">${s.icon}</div>
      <div class="step">Step ${i + 1} of ${slides.length}</div>
      <h1>${s.title}</h1>
      <p class="sub">${s.subtitle || ''}</p>
      <ul class="features">
        ${s.features.map(([t, d], n) => `
          <li><span class="num">${n + 1}</span><div><h3>${t}</h3><p>${d}</p></div></li>`).join('')}
      </ul>
    </article>`).join('');
  dots.innerHTML = slides.map(() => '<span class="dot"></span>').join('');
  go(index);
}

function go(i) {
  index = Math.max(0, Math.min(slides.length - 1, i));
  track.style.transform = `translateX(-${index * 100}%)`;
  document.querySelectorAll('.slide').forEach((el, n) => el.classList.toggle('active', n === index));
  document.querySelectorAll('.dot').forEach((el, n) => el.classList.toggle('on', n === index));
  card.style.setProperty('--accent', slides[index].accent);
  backBtn.hidden = index === 0;
  const last = index === slides.length - 1;
  nextBtn.textContent = last ? 'Get Started' : 'Next';
  skipBtn.style.visibility = last ? 'hidden' : 'visible';
  saveProgress({ completed: false, skipped: false });
}

// ====== 6) Save progress (Supabase if signed in, always localStorage) ======
async function saveProgress({ completed, skipped }) {
  try {
    localStorage.setItem('peerhub_onboarding', JSON.stringify({ last: index + 1, completed, skipped }));
  } catch (_) {}
  if (!supa) return;
  try {
    const { data: { session } } = await supa.auth.getSession();
    if (!session) return; // not signed in yet: local only
    await supa.rpc('save_onboarding_progress', {
      p_last_slide: index + 1, p_completed: completed, p_skipped: skipped,
    });
  } catch (e) { console.warn('Progress save failed', e); }
}

function finish(skipped) {
  saveProgress({ completed: !skipped, skipped });
  const d = document.createElement('div');
  d.className = 'done show';
  d.innerHTML = `<div style="font-size:56px">🎉</div><h2>You're all set!</h2><p>Taking you to PeerHub…</p>`;
  card.appendChild(d);
  setTimeout(() => (window.location.href = 'register.html'), 1200);
}

// ====== 7) Events ======
nextBtn.addEventListener('click', () => (index === slides.length - 1 ? finish(false) : go(index + 1)));
backBtn.addEventListener('click', () => go(index - 1));
skipBtn.addEventListener('click', () => finish(true));
document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowRight') nextBtn.click();
  if (e.key === 'ArrowLeft') go(index - 1);
});
// Swipe support
let x0 = null;
track.addEventListener('touchstart', (e) => (x0 = e.touches[0].clientX), { passive: true });
track.addEventListener('touchend', (e) => {
  if (x0 === null) return;
  const dx = e.changedTouches[0].clientX - x0;
  if (Math.abs(dx) > 50) go(index + (dx < 0 ? 1 : -1));
  x0 = null;
});

// ====== 8) Init ======
(async function init() {
  // Already finished or skipped before? Go straight to the app. (Add ?replay to index.html to see the slides again.)
  try {
    const saved = JSON.parse(localStorage.getItem('peerhub_onboarding') || 'null');
    if (saved && (saved.completed || saved.skipped) && !location.search.includes('replay')) {
      window.location.replace('register.html'); return;
    }
  } catch (_) {}
  slides = await loadSlides();
  render();
})();
