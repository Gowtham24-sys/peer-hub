/* PeerHub — turn a selfie into a cartoon "face emoji".
   Everything happens on the phone (no AI key, no server, always works):
   1) crop the face to a circle  2) smooth + posterize the colours + draw dark outlines (cartoon look)
   3) draw emoji-style eyes / mouth / brows for each feeling on top (SVG). Animation comes from the page's CSS.
   Saved result is small: { t:'toon', img:<160px jpeg data url>, skin:'#hex', moods:[...] } */
window.FE = (() => {
  const N = 160, D = '#2b2233';
  const loadImg = (file) => new Promise((res, rej) => { const u = URL.createObjectURL(file), i = new Image(); i.onload = () => { URL.revokeObjectURL(u); res(i); }; i.onerror = () => rej(new Error('Could not open this photo')); i.src = u; });

  // square crop; zoom 1..3, ox/oy -1..1 move the crop window
  function crop(img, zoom, ox, oy) {
    const c = document.createElement('canvas'); c.width = c.height = N; const g = c.getContext('2d');
    const s = Math.min(img.width, img.height) / Math.max(1, zoom), sx = (img.width - s) / 2 * (1 + ox), sy = (img.height - s) / 2 * (1 + oy);
    g.fillStyle = '#fff'; g.fillRect(0, 0, N, N); g.drawImage(img, sx, sy, s, s, 0, 0, N, N); return c;
  }
  function blur(src, w, h) {   // 3x3 box blur on a Float32 RGB buffer
    const out = new Float32Array(src.length);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) for (let k = 0; k < 3; k++) {
      let s = 0, n = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue; s += src[(yy * w + xx) * 3 + k]; n++; }
      out[(y * w + x) * 3 + k] = s / n;
    }
    return out;
  }
  function cartoonize(c) {
    const g = c.getContext('2d'), d = g.getImageData(0, 0, N, N), px = d.data;
    let a = new Float32Array(N * N * 3); for (let i = 0; i < N * N; i++) { a[i * 3] = px[i * 4]; a[i * 3 + 1] = px[i * 4 + 1]; a[i * 3 + 2] = px[i * 4 + 2]; }
    a = blur(blur(a, N, N), N, N);
    const lum = new Float32Array(N * N); for (let i = 0; i < N * N; i++) lum[i] = 0.299 * a[i * 3] + 0.587 * a[i * 3 + 1] + 0.114 * a[i * 3 + 2];
    const L = 6, q = (v) => Math.max(0, Math.min(255, Math.round(v / 255 * (L - 1)) / (L - 1) * 255));
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
      const i = y * N + x, l = lum[i];
      // Sobel edges on the smoothed brightness
      let e = 0;
      if (x > 0 && y > 0 && x < N - 1 && y < N - 1) {
        const gx = -lum[i - N - 1] - 2 * lum[i - 1] - lum[i + N - 1] + lum[i - N + 1] + 2 * lum[i + 1] + lum[i + N + 1];
        const gy = -lum[i - N - 1] - 2 * lum[i - N] - lum[i - N + 1] + lum[i + N - 1] + 2 * lum[i + N] + lum[i + N + 1];
        e = Math.sqrt(gx * gx + gy * gy);
      }
      const dark = e > 70 ? 0.28 : e > 45 ? 0.6 : 1;
      for (let k = 0; k < 3; k++) { const v = l + (a[i * 3 + k] - l) * 1.3 + 8; px[i * 4 + k] = q(v) * dark; }   // a little more colour, then flat shades
      px[i * 4 + 3] = 255;
    }
    g.putImageData(d, 0, 0);
    // skin colour = average of the two cheeks
    let r = 0, gg = 0, b = 0, n = 0;
    [[.26, .56], [.62, .56]].forEach(([fx, fy]) => { const p = g.getImageData(Math.round(fx * N), Math.round(fy * N), Math.round(.12 * N), Math.round(.1 * N)).data; for (let i = 0; i < p.length; i += 4) { r += p[i]; gg += p[i + 1]; b += p[i + 2]; n++; } });
    const hx = (v) => Math.round(v / n).toString(16).padStart(2, '0');
    return { img: c.toDataURL('image/jpeg', 0.78), skin: '#' + hx(r) + hx(gg) + hx(b) };
  }
  // file/blob (or an already loaded image) -> { img, skin }
  async function make(src, o) {
    o = Object.assign({ zoom: 1.2, ox: 0, oy: 0 }, o || {});
    const img = src instanceof HTMLImageElement ? src : await loadImg(src);
    return cartoonize(crop(img, o.zoom, o.ox, o.oy));
  }

  let uid = 0;
  const heart = (x, y) => `<path transform="translate(${x} ${y}) scale(.95)" d="M0 -4 C-7 -12 -15 -2 0 10 C15 -2 7 -12 0 -4 Z" fill="#ff2e63" stroke="#a3102e" stroke-width="1.2"/>`;
  const st = (d, w) => `<path d="${d}" fill="none" stroke="${D}" stroke-width="${w || 3.2}" stroke-linecap="round" stroke-linejoin="round"/>`;
  function svg(f, mood) {
    const id = 'fe' + (++uid), sk = f.skin || '#e0ac69';
    const eyeP = `<ellipse cx="34" cy="43" rx="11" ry="8.5" fill="${sk}" filter="url(#${id}b)"/><ellipse cx="66" cy="43" rx="11" ry="8.5" fill="${sk}" filter="url(#${id}b)"/>`;
    const mouthP = `<ellipse cx="50" cy="71" rx="17" ry="9" fill="${sk}" filter="url(#${id}b)"/>`;
    const wideEye = (x) => `<circle cx="${x}" cy="43" r="8.5" fill="#fff" stroke="${D}" stroke-width="1.8"/><circle cx="${x}" cy="43" r="3.6" fill="${D}"/>`;
    const angryEye = (x, px) => `<ellipse cx="${x}" cy="45" rx="6.5" ry="4.5" fill="#fff" stroke="${D}" stroke-width="1.6"/><circle cx="${px}" cy="45.5" r="2.6" fill="${D}"/>`;
    const M = {
      laugh: eyeP + mouthP + st('M25 46 Q34 35 43 46') + st('M57 46 Q66 35 75 46')
        + `<path d="M31 62 Q50 94 69 62 Z" fill="#5a1d1d" stroke="${D}" stroke-width="2.2" stroke-linejoin="round"/><path d="M34 63.5 Q50 70 66 63.5 L66 61 L34 61 Z" fill="#fff"/><ellipse cx="50" cy="77" rx="8" ry="4.5" fill="#ff6b81"/>`,
      cry: eyeP + mouthP + st('M25 44 Q34 52 43 44') + st('M57 44 Q66 52 75 44') + st('M24 33 L42 38', 3.6) + st('M76 33 L58 38', 3.6) + st('M38 79 Q50 67 62 79'),
      angry: eyeP + mouthP + angryEye(34, 35.5) + angryEye(66, 64.5) + st('M22 30 L45 40', 4.6) + st('M78 30 L55 40', 4.6) + st('M36 77 Q50 66 64 77') + '<circle cx="50" cy="50" r="50" fill="#ff2d2d" opacity=".18"/>',
      love: eyeP + mouthP + heart(34, 43) + heart(66, 43) + st('M34 66 Q50 84 66 66', 3.4),
      wow: eyeP + mouthP + wideEye(34) + wideEye(66) + st('M24 27 Q34 20 44 27') + st('M56 27 Q66 20 76 27')
        + `<ellipse cx="50" cy="75" rx="7.5" ry="10" fill="#5a1d1d" stroke="${D}" stroke-width="2.2"/>`,
      cool: mouthP + '<rect x="19" y="35" width="29" height="17" rx="6" fill="#111"/><rect x="52" y="35" width="29" height="17" rx="6" fill="#111"/><rect x="46" y="39" width="8" height="3.5" fill="#111"/>'
        + '<path d="M24 39 L32 39 M57 39 L65 39" stroke="#fff" stroke-width="2" opacity=".55" stroke-linecap="round"/>' + st('M38 70 Q52 80 64 68', 3.4),
    };
    return `<svg viewBox="0 0 100 100"><defs><clipPath id="${id}c"><circle cx="50" cy="50" r="50"/></clipPath><filter id="${id}b" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="2"/></filter></defs>`
      + `<g clip-path="url(#${id}c)"><image href="${f.img}" x="0" y="0" width="100" height="100" preserveAspectRatio="xMidYMid slice"/>${M[mood] || ''}</g><circle cx="50" cy="50" r="48.6" fill="none" stroke="${D}" stroke-width="2.8"/></svg>`;
  }
  return { make, loadImg, svg };
})();
