/* PeerHub minimal service worker: makes the app installable.
   Network first; if offline, falls back to a cached copy of pages/files already visited.
   API calls (Supabase etc.) are never cached. Bump VERSION to clear old caches. */
const VERSION = 'peerhub-v1';
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin) return;   // only our own files
  e.respondWith(
    fetch(r).then((res) => { if (res.ok) { const c = res.clone(); caches.open(VERSION).then((ch) => ch.put(r, c)); } return res; })
      .catch(() => caches.match(r).then((m) => m || caches.match('index.html')))
  );
});
